* [Home](/)


* Reference documentation
	* [Agents](BiteAgent.md)
	* [Cell](BiteCell.md)
	* [Engine](BiteEngine.md)
	* [expressions, events, variables](variables.md)

* Items
	* [BiteDispersal](BiteDispersal.md)
	* [BiteDistribution](BiteDistribution.md)
	* [BiteColonization](BiteColonization.md)
	* [BiteBiomass](BiteBiomass.md)
	* [BiteImpact](BiteImpact.md)
	* [BiteLifeCycle](BiteLifeCycle.md)
	* [BiteOutput](BiteOutput.md)
  

* ![BITE](img/bite_logo.png)
