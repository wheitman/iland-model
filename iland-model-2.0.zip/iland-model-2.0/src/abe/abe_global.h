#ifndef FOME_GLOBAL_H
#define FOME_GLOBAL_H

#include <QtCore>

#include <QJSEngine>
#include <QJSValue>
#include <QJSValueIterator>

#include <QLoggingCategory>
Q_DECLARE_LOGGING_CATEGORY(abe)
Q_DECLARE_LOGGING_CATEGORY(abeSetup)


#endif // FOME_GLOBAL_H
