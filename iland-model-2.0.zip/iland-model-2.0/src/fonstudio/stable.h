/****************************************************************************
**
**
****************************************************************************/

//! [0]
/* Add C includes here */

#if defined __cplusplus
/* Add C++ includes here */

#include <iostream>
#include <QtGui>
#include <QtXml>
#include <QtSql>
//#include <QHttp>
//#include <QTXml>

//
#include <math.h>

// globals of project
#include "global.h"
#endif
//! [0]
