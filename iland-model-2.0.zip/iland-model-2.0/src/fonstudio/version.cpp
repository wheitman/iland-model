const char *version = "Alpha 0.1";
const char *svn_revision = "354M";
const char *currentVersion(){ return version;}
const char *svnRevision(){ return svn_revision;}
