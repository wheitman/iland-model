// global functions for current version and svn-revision. version.cpp gets updated automatically.
const char *currentVersion();
const char *svnRevision();

