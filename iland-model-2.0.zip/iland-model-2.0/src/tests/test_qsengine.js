// test for some features of the Qt-API

function test_factory()
{
	print("create CSVFile");
	var csvfile = Factory.newCSVFile("asdf");
	print(csvfile);
	//var cc = Factory.newClimateConverter();
	//print(cc);
}
